	// create the module and name it scotchApp
	var myapp = angular.module('myApp', ['ngRoute']);

	// configure our routes
	myapp.config(function($routeProvider) {
		$routeProvider

			// route for the about page
			.when('/home', {
				templateUrl : 'home.html',
				controller  : 'mainController'
			})

			// route for the contact page
			.when('/home/:search', {
				templateUrl : 'home.html',
				controller  : 'mainController'
			});
	});

	// create the controller and inject Angular's $scope
	myapp.controller('mainController', function($scope, $routeParams, $window) {
		// create a message to display in our view
		$scope.message = 'Everyone come and see how good I look!';
		debugger;
		$window;
		$scope.params = $routeParams.search;
		if($scope.params === "name") {
			$scope.message = "shiva";
		} else if($scope.params === "empId") {
			$scope.message = "74125_IN";
		} else if($scope.params === "position") {
			$scope.message = "Associate";
		}
	});
